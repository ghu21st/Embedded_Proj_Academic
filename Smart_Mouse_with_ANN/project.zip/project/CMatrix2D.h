//Basic windows 2D matrix class for calculating any 2D object transformation
#ifndef CMATRIX2D_H
#define CMATRIX2D_H
//
#include "utility.h"
#include "math.h"
#include "stdlib.h"
#include "string.h"
#include <sstream>
#include <vector>
#include "windows.h"

struct SPoint;

using namespace std;
//
struct SMat2D{
	double m11, m12, m13;
	double m21, m22, m23;
	double m31, m32, m33;

	SMat2D(){
		m11=0; m12=0; m13=0;
		m21=0; m22=0; m23=0;
		m31=0; m32=0; m33=0;
	}

/*	//overload the operator '<<' for display 
	friend ostream &operator<<(ostream& os, const SMat2D &s2D)
  	{
		os << "\n" << s2D.m11 << " " << s2D.m12 << " " << s2D.m13;
		os << "\n" << s2D.m21 << " " << s2D.m22 << " " << s2D.m23;
		os << "\n" << s2D.m31 << " " << s2D.m32 << " " << s2D.m33;

		return os;
	}
*/	
};
//
class CMat2DTrans{
private:
	SMat2D m_Mat2D;

public:
	CMat2DTrans(){ Identity_Mat();}
	void Identity_Mat();
	
	//Input value seq.: SPoint vector, rotation, scale x, scale y, translate x, translate y
	void Vertex_Transform2D(vector<SPoint> &v_In, double rot, double sx, double sy, 
								double dx, double dy);
};

#endif