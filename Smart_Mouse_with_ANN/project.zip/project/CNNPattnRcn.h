//Neural Network mouse pattern recognition 1.0
#ifndef CNNPATTNRCN_H
#define CNNPATTNRCN_H
//
#pragma warning (disable: 4786)
//
#include "Define.h"
#include "Utility.h"
#include "CData.h"
#include "CNeuralNet.h"
#include "SVector2D.h"
//#include "Windows_Def.h"

#include "windows.h"
#include <vector>
#include <sstream>
#include "math.h"
//#include <fstream>

using namespace std;
//
enum PR_RunMode{UNREADY, LEARNING, TRAINING, DIAGNOSING, READY}; //ANN standard procedure defination

//CNNPattnRcn class defination
class CNNPattnRcn{
//private:
protected:
	//define NN and data
	CNeuralNet *m_pNN;
	CData *m_pData;

	//mouse input data
	vector<POINTS> m_vPathPoints;	//original input points vector <POINTS>
	vector<POINTS> m_vScaleDownPoints;	//scaled down points vector
	vector<double> m_vectData;	//reday data for NN

	int m_iNumDefPoints;
	bool m_bActed;	//false: mouse rec not acted, true: acted
	
	int m_iNewInputNum;	//new input number 

	//Pattern matched variables
	double m_dHighestOutput;//highest recognition possibility
	int m_iBestFit;			//best fitness pattern number
	int m_iMatchedPattern;	//found matched pattern number (over threshold)

	int m_iNumPatterns;

	//control flag of mode
	PR_RunMode m_PRMode;

	//window handle
	HWND m_hWnd;

	//user input dialog for windows
	static BOOL CALLBACK DataInputDlgProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
	
	//input dialog data
	static string m_strInputData;

	//input diagnose test file name
	char chFN_Square[80];
	char chFN_Triangle[80];

public:	//member functions
	void Clear();	//clear data vectors
	void GenerateInputData(vector<POINTS> v_In);	//after scale down, normalize input to suit for NN input need
	bool PointsScaleDown(vector<POINTS> v_In);	//scale down points
	bool MatchTest();	//test for a match from output vector

public:
	//construction & destruction
	CNNPattnRcn(HWND hwnd);
	~CNNPattnRcn();

	//func. for NN oper.
	bool TrainNN();		//Training mode
	void Render(HDC &hdc, int cxClient, int cyClient); //Render the window
	bool WIN_Action(bool bIn, HINSTANCE hInst);	//drawing process
	void LearningMode();	//Learning mode
	bool DiagnoseNN(bool iFlag);	//Diagnosing mode
	void AddPoints(POINTS pIn){ m_vPathPoints.push_back(pIn);}	//Points adding
	
	double Diag_Test(vector<POINTS> v_In);	//for diagnose using
	
	//
	bool matchExec(int iIn);

	//access methods
	bool getActionFlag(){return m_bActed;}
	PR_RunMode getPRMode(){return m_PRMode;}
	double getHighestOutput(){return m_dHighestOutput;}
	string getPatternName(){return m_pData->getPatternName(m_iBestFit);}

};

#endif