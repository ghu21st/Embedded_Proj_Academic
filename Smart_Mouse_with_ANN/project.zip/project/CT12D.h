//Define a windows 2D object class
#ifndef CT12D_H
#define CT12D_H
//
#include "CMatrix2D.h"
#include "SVector2D.h"
#include "utility.h"
//#include "Windows_Def.h"
#include "CNNPattnRcn.h"

#include "windows.h"
#include "string.h"
#include <vector>
#include <sstream>
#include <fstream>
//**************************************************
//define for the object transform parameters
#define PI 3.1415926
#define ROTATE_STEP 0.0524 //+/-45 degree, 30 data points, so 90/30=3, 3/180*PI=0.0524
#define SCALE_STEP 0.1
#define MOVE_STEP 2
#define FORWARD_STEP 5

//#define SQUARE_POINTNUM 4
//#define TRIANGLE_POINTNUM 3
#define SQUARE_POINTNUM 16
#define TRIANGLE_POINTNUM 16

//define keyboard input detect macro
#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_c/ode) & 0x8000) ? 0 : 1)
//****************************************************
//
using namespace std;
//
class CT12D{
public:

	vector<SPoint> m_vT1VB;	//main vector to keep all predefined points (vertex) 2D coodinate	
	vector<SPoint> m_vSquareVB;
	vector<SPoint> m_vTriangleVB;
	vector<SPoint> m_vT1VBTrans; //for temporarily keep m_vT1VB

	POINTS m_vPT;
/*	vector<POINTS> m_vT1VB;	//main vector to keep all predefined points (vertex) 2D coodinate	
	vector<POINTS> m_vSquareVB;
	vector<POINTS> m_vTriangleVB;
	vector<POINTS> m_vT1VBTrans; //for temporarily keep m_vT1VB
*/
//	vector<POINTS> m_vPathPoints;

	double m_dPosX; 
	double m_dPosY;
	double m_dRotation;
	double m_dScale;

	int m_iTestFlag; //test start flag
	int m_iPointNum; //tested shape point numbers
	int m_iRecStop; //record test data into file stop sign flag
	int m_iShapeN; //0-square, 1-triangle
	
	//inner transform 
	double m_dAngle;

	//get windows height for text out at the bottom
	double m_WinHeight;
	double m_WinWidth;

	//mode setting
	int m_iMode;

	//recog shape for diagnosing
	CNNPattnRcn *pNNRcn;

	//
	bool Diagnose_Points(HDC hdc, vector<SPoint> v_In, int i_In);	//input: vector &points number, return match or not

	CT12D(double rotate, double scale, int x, int y, HWND hwnd);
	void Render(HDC hdc, int cxClient, int cyClient);
	void UpdateInput();

	//
	bool setMode(int iIn);	//=0, Learning mode; =1, training mode, =2, diagnose mode enter, =3, diagnose mode quit
	int getMode(){return m_iMode;}

	bool setAction(bool bIn, HINSTANCE hInst){return pNNRcn->WIN_Action(bIn, hInst);}
	bool getActionFlag(){return pNNRcn->getActionFlag();}

	void AddPoints(POINTS pIn){pNNRcn->AddPoints(pIn);}

	void NNRender(HDC hdc, int cxClient, int cyClient){pNNRcn->Render(hdc, cxClient, cyClient);}

};

#endif