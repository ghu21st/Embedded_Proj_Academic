//Implememtation of CT12D.h
#include "CT12D.h"
//
//----------------------------------------------
	//init the shape 

//square shape defination
const SPoint Square_Vertex[SQUARE_POINTNUM]={
	//vector: 1,0,1,0,1,0,1,0,0,-1,0,-1,0,-1,0,-1,-1,0,-1,0,-1,0,-1,0,0,1,0,1,0,1,0,1, //_, |, -, |
	//16 points CCW square
	//-2,2, -1,2, 0,2, 1,2, 2,2, 2,1, 2,0, 2,-1, 2,-2, 1,-2, 0,-2, -1,-2, -2,-2, -2,-1, -2,0, -2,1
	SPoint(-2,2), SPoint(-1,2), SPoint(0,2), SPoint(1,2),
	SPoint(2,2), SPoint(2,1), SPoint(2,0), SPoint(2,-1),
	SPoint(2,-2), SPoint(1,-2), SPoint(0,-2), SPoint(-1,-2),
	SPoint(-2,-2), SPoint(-2,-1), SPoint(-2,0), SPoint(-2,1)

};

	//init vector original direction
SVector2D vectDir(0, 1);

//triangle shape defination (equal edge), counter-clockwise triangle
const SPoint Triangle_Vertex[TRIANGLE_POINTNUM]={
	//vector:	1,0,1,0,1,0,1,0,1,0,1,0,-0.5,-0.866,-0.5,-0.866,-0.5,-0.866,-0.5,-0.866,-0.5,-0.866,-0.5,0.866,-0.5,0.866,-0.5,0.866,-0.5,0.866,-0.5,0.866, // _, \, /
	//16 points CCW triangle
	//-3,1.732, -2,1.732, -1,1.732, 0,1.732, 1,1.732, 2,1.732, 3,1.732, 2.4,0.693, 1.8,-0.346, 1.2,-1.386, 0.6,-2.425, 0,-3.464, -0.6,-2.425, -1.2,-1.386, -1.8,-0.346, -2.4,0.693
	SPoint(-3,1.732), SPoint(-2,1.732), SPoint(-1,1.732), SPoint(0,1.732),
	SPoint(1,1.732), SPoint(2,1.732), SPoint(3,1.732), SPoint(2.4,0.693),
	SPoint(1.8,-0.346), SPoint(1.2,-1.386), SPoint(0.6,-2.425), SPoint(0,-3.464),
	SPoint(-0.6,-2.425), SPoint(-1.2,-1.386), SPoint(-1.8,-0.346), SPoint(-2.4,0.693)
};

const char chFN_Square[50]="Square_Trans.dat";
const char chFN_Triangle[50]="Triangle_Trans.dat";
const char chFN_Angle[50]="Angle_Table.dat";

//-----------------------------------------------
//
CT12D::CT12D(double rotate, double scale, int x, int y, HWND hwnd)
{
	//*******init inner transform*********
//	m_dAngle=-PI/2; 
	m_dAngle=0; 
	//************************************

	//initialize the internal variables for 2D object
	m_dPosX=x/2; m_dPosY=y/2;
	m_dRotation=rotate+m_dAngle; 
	m_dScale=scale;

	//init the flag
	m_iTestFlag=0;
	m_iRecStop=0;
	m_iShapeN=0; //0-square, 1-triangle,

	//
	m_iMode=1;
	
	//
	pNNRcn=new CNNPattnRcn(hwnd);

}

bool CT12D::setMode(int iIn)	//=0, Learning mode; =1, training mode, =2, diagnose mode enter, =3, diagnose mode quit
{
	bool bRet;
	//
	m_iMode=iIn;
	//
	switch(iIn){
	case 0:
		pNNRcn->LearningMode();
		break;

	case 1:
		bRet=pNNRcn->TrainNN();	
		break;
	
	case 2:
		bRet=pNNRcn->DiagnoseNN(true);
		break;
		
	case 3:
		bRet=pNNRcn->DiagnoseNN(false);
		break;

	}

	return bRet;

}


void CT12D::Render(HDC hdc, int cxClient, int cyClient)
{
	static int iN1=0; //for test data generation counter (-15 to 15)
	
	static int iX_step=3;
	static int iY_step=3;

	//clear the general used vertex 
	m_vT1VB.clear(); m_vT1VBTrans.clear();

	//Draw the new object on screen
	if(m_iTestFlag==0){		//draw new object to reponse keyboard input
		//init triangle vertex
		for(int i2=0; i2<TRIANGLE_POINTNUM; i2++){
			m_vT1VB.push_back(Triangle_Vertex[i2]);
		}
		m_iPointNum=TRIANGLE_POINTNUM;
		
		m_vT1VBTrans=m_vT1VB;	//keep the original vertex vector
		
		//Transform the object to a new position, shape and rotation angle as wanted
		CMat2DTrans m_Mat2DTrans;
		m_Mat2DTrans.Vertex_Transform2D(m_vT1VBTrans, m_dRotation, m_dScale, m_dScale,
										m_dPosX, m_dPosY);
		//
		Diagnose_Points(hdc, m_vT1VBTrans, m_iPointNum);

		//
		iN1=0;
	}else{			//draw all test data on screen 
		int i1, i2;
		//
		switch(m_iShapeN){
		case 0:	//init square vertex 
			for(i1=0; i1<SQUARE_POINTNUM; i1++){
				m_vT1VB.push_back(Square_Vertex[i1]);
			}
			m_iPointNum=SQUARE_POINTNUM;
			break;

		case 1:	//init triangle vertex
			for(i2=0; i2<TRIANGLE_POINTNUM; i2++){
				m_vT1VB.push_back(Triangle_Vertex[i2]);
			}
			m_iPointNum=TRIANGLE_POINTNUM;
			break;
			
		case 2: //end the shape change loop, back to 0
			m_iShapeN=0;
			m_iTestFlag=0;	//finish automatic test, back to normal 
			m_iRecStop=1;	//stop test data recording into the file
			return;
			break;
		}
/*		
		//show the shape change on screen
		//1) 0 to 60 degree, plus, 15 data steps, CCW
		if(iN1==0 || iN1==16 ||iN1==31){
//			m_dRotation=-PI/2; //init angle 
			m_dRotation=0; //init angle 

		}else if(iN1<16){ //CCW
			m_dRotation-=ROTATE_STEP;

		}else if((iN1>16)&&(iN1<31)){
			
		//2) 0 to -60 degree, minus, 15 data step, CW
			m_dRotation+=ROTATE_STEP;
		}
		
		if(iN1>=31 && iN1<46){ //judge if over 30 steps totally
			m_dPosX+=iX_step;
			m_dPosY-=iY_step;
		}else if(iN1==46){
			m_dPosX=cxClient/2; 
			m_dPosY=cyClient/2;
		}else if(iN1>46 && iN1<=61){
			m_dPosX-=iX_step;
			m_dPosY-=iY_step;
		}else if(iN1>61){
			//
			iN1=0;	//return to zero
			m_iShapeN++; //increase shape # and change showing
			
			//back to origin point to restart
			m_dPosX=cxClient/2; 
			m_dPosY=cyClient/2;
		}
*/		
		//show the shape change on screen
		//1) 0 to 60 degree, plus, 15 data steps, CCW
		if(iN1==0){
//			m_dRotation=-PI/2; //init angle 
			m_dRotation=ROTATE_STEP*(-15); //init angle 

		}else if(iN1>30){
			//
			iN1=0;	//return to zero
			m_dRotation=ROTATE_STEP*(-15); //init angle 

			m_iShapeN++; //increase shape # and change showing
			
			//back to origin point to restart
			m_dPosX=cxClient/2; 
			m_dPosY=cyClient/2;
		}

		//2) -45 to 45 degree
		m_dRotation+=ROTATE_STEP;

		iN1++;
		//
		m_vT1VBTrans=m_vT1VB;	//keep the original vertex vector
		
		//Transform the object to a new position, shape and rotation angle as wanted
		CMat2DTrans m_Mat2DTrans;
		m_Mat2DTrans.Vertex_Transform2D(m_vT1VBTrans, m_dRotation, m_dScale, m_dScale,
										m_dPosX, m_dPosY);
		//give recognition result
		Diagnose_Points(hdc, m_vT1VBTrans, m_iPointNum);

		//
		Sleep(20);
		//
	}

	//update the drawing
	MoveToEx(hdc, m_vT1VBTrans[0].x, m_vT1VBTrans[0].y, NULL);
	for(int i=0; i<m_iPointNum; i++){
		LineTo(hdc, m_vT1VBTrans[i].x, m_vT1VBTrans[i].y);
	}
	LineTo(hdc, m_vT1VBTrans[0].x, m_vT1VBTrans[0].y);
	//
	//Text out to show the parameters.
	ostringstream buf1, buf2, buf3, buf4;
	buf1<<-(m_dRotation-m_dAngle); buf2<<m_dScale; 
	buf3<<m_dPosX; buf4<<m_dPosY;

	string s1="Position: "+buf3.str()+", "+buf4.str();
	string s2="\nRotation: "+buf1.str();
	string s3="\nScale:"+buf2.str();

	string s4="'Y'-start, 'Q'-return, 'A'-left, 'W'-up, 'D'-right, 'S'-down";
	string s5="'M'-scaleup, 'N'-scaledown, '->'-rotate right, '<-'-rotate left";

	TextOut(hdc, 5, 10, s1.c_str(), s1.size());
	TextOut(hdc, 5, 30, s2.c_str(), s2.size());
	TextOut(hdc, 5, 50, s3.c_str(), s3.size());

	TextOut(hdc, 5, cyClient-40, s4.c_str(), s4.size());
	TextOut(hdc, 5, cyClient-20, s5.c_str(), s5.size());

}

void CT12D::UpdateInput()
{	
	//if it is in the automatic test status, no keyboard update
	if(m_iTestFlag){
		return;
	}

	//detect & update the keyboard input 	
	if(KEYDOWN(VK_LEFT)){ //rotate counter-clockwise
		m_dRotation-=ROTATE_STEP;
		if(m_dRotation<(-2*PI+m_dAngle)){
			m_dRotation=m_dAngle;
		}

		//update dir vector
		vectDir.x=1*cos((m_dRotation-m_dAngle));
		vectDir.y=1*sin((m_dRotation-m_dAngle));
	}

	if(KEYDOWN(VK_RIGHT)){ //rotate clockwise
		m_dRotation+=ROTATE_STEP;
		if(m_dRotation>2*PI+m_dAngle){
			m_dRotation=m_dAngle;
		}

		//update dir vector
		vectDir.x=1*cos((m_dRotation-m_dAngle));
		vectDir.y=1*sin((m_dRotation-m_dAngle));
	}

	if(KEYDOWN(VK_UP)){	//move forward
		m_dPosX-=FORWARD_STEP*vectDir.x;
		m_dPosY-=FORWARD_STEP*vectDir.y;

		m_iTestFlag=0;
	}
	
	if(KEYDOWN(VK_DOWN)){ //move backward
		m_dPosX+=FORWARD_STEP*vectDir.x;
		m_dPosY+=FORWARD_STEP*vectDir.y;

		m_iTestFlag=0;
	}

	if(KEYDOWN('M')){	//scale up
		m_dScale+=SCALE_STEP;
	}
	
	if(KEYDOWN('N')){	//scale down
		if(m_dScale<SCALE_STEP){
			m_dScale=SCALE_STEP;
		}else{
			m_dScale-=SCALE_STEP;
		}
	}

	if(KEYDOWN('A')){	//move left
		m_dPosX-=MOVE_STEP;
	
		m_iTestFlag=0;
	}
	
	if(KEYDOWN('D')){	//move right
		m_dPosX+=MOVE_STEP;
		
		m_iTestFlag=0;
	}
	
	if(KEYDOWN('W')){	//move up
		m_dPosY-=MOVE_STEP;
		
		m_iTestFlag=0;
	}
	
	if(KEYDOWN('S')){	//move down
		m_dPosY+=MOVE_STEP;
		
		m_iTestFlag=0;
	}

	//start the generation of the test data for mouse guesture use
	if(KEYDOWN('Y')){
		m_iTestFlag=1;
			//permit to record the shape data into file
		m_iRecStop=0;

		//clear and delete the old record file
		ofstream Square_Rec(chFN_Square);
		Square_Rec<<"";
		Square_Rec.close();
		ofstream Triangle_Rec(chFN_Triangle);
		Triangle_Rec<<"";
		Triangle_Rec.close();
		ofstream AngleTab_Rec(chFN_Angle);
		AngleTab_Rec<<"";
		AngleTab_Rec.close();
	}
	//
	
}
//-------------------------------------------------------------
//
bool CT12D::Diagnose_Points(HDC hdc, vector<SPoint> v_In, int i_In)
{
	POINTS point_In;
	double dRet; bool bRet=true;
	vector<POINTS> v_PathPoints;
	//
	pNNRcn->Clear();
	v_PathPoints.clear();

	//collect all the points data
	for(int iv=0; iv<i_In; iv++){
		point_In.x=v_In[iv].x;
		point_In.y=v_In[iv].y;
		v_PathPoints.push_back(point_In);
	}
		//add the last point (same as the first one)
	point_In.x=v_In[0].x;
	point_In.y=v_In[0].y;
	v_PathPoints.push_back(point_In);

	//
	dRet=pNNRcn->Diag_Test(v_PathPoints);
	//
	ostringstream buf_Ret1, buf_Ret2;
	buf_Ret1<<pNNRcn->getPatternName(); buf_Ret2<<dRet; 

	string s_Ret1="Pattern: "+buf_Ret1.str();
	string s_Ret2="Guessing: "+buf_Ret2.str();

	TextOut(hdc, 200, 10, s_Ret1.c_str(), s_Ret1.size());
	TextOut(hdc, 200, 30, s_Ret2.c_str(), s_Ret2.size());
	//
	//record the shape data into file when it is in the automatic test status
	if(m_iTestFlag){
		if(m_iRecStop==0){
			//record the new data
			if(m_iShapeN==0){	//Square
				ofstream Square_Rec(chFN_Square, ios::app);		
	//			Square_Rec<<m_dRotation;
	//			Square_Rec<<" ";
				Square_Rec<<dRet;
				Square_Rec<<"\n";
				Square_Rec.close();

			}else if(m_iShapeN==1){ //triangle
				ofstream Triangle_Rec(chFN_Triangle, ios::app);
	//			Triangle_Rec<<m_dRotation;
	//			Triangle_Rec<<" ";
				Triangle_Rec<<dRet;
				Triangle_Rec<<"\n";
				Triangle_Rec.close();
			}

			//create a standard angle changed table
			ofstream AngleTab_Rec(chFN_Angle, ios::app);
			AngleTab_Rec<<m_dRotation;
			AngleTab_Rec<<"\n";
			AngleTab_Rec.close();

		}
	}
	//
	return bRet;

}
		//record the shape data into file
/*		if(m_iRecStop==0){
			//record the new data
			if(m_iShapeN==0){	//Square
				ofstream Square_Rec(chFN_Square, ios::app);		
				for(int n=0; n<m_iPointNum; n++){
					Square_Rec<<m_vT1VBTrans[n].x;
					Square_Rec<<m_vT1VBTrans[n].y;
				}
				Square_Rec.close();

			}else if(m_iShapeN==1){ //triangle
				ofstream Triangle_Rec(chFN_Triangle, ios::app);
				for(int n=0; n<m_iPointNum; n++){
					Triangle_Rec<<m_vT1VBTrans[n].x;
					Triangle_Rec<<m_vT1VBTrans[n].y;
				}
				Triangle_Rec.close();
			}
		}
*/

/*
	//	bRet=pNNRcn->PointsScaleDown(v_PathPoints);
	pNNRcn->GenerateInputData(v_PathPoints);
	bRet=pNNRcn->MatchTest();
	dRet=pNNRcn->getHighestOutput() * 100;
*/
	
//-------------------------------------------------------------
//const SPoint Square_Vertex[SQUARE_POINTNUM]={

	//counter-clockwise square
/*	
	//16 points CCW square
		SPoint(1,0), SPoint(1,0), SPoint(1,0), SPoint(1,0), 
		SPoint(0,-1), SPoint(0,-1), SPoint(0,-1), SPoint(0,-1), 
		SPoint(-1,0), SPoint(-1,0), SPoint(-1,0), SPoint(-1,0), 
		SPoint(0,1), SPoint(0,1), SPoint(0,1), SPoint(0,1)
*/

//const SPoint Triangle_Vertex[TRIANGLE_POINTNUM]={

//	SPoint(-1, 0.5774), SPoint(1, 0.5774), SPoint(0, -1.1547) //three point triangle
/*
	//16 points CCW triangle
	SPoint(1, 0), SPoint(1, 0), SPoint(1, 0),
	SPoint(1, 0), SPoint(1, 0), SPoint(1, 0),
	SPoint(-0.5, -0.866), SPoint(-0.5, -0.866), SPoint(-0.5, -0.866),
	SPoint(-0.5, -0.866), SPoint(-0.5, -0.866),
	SPoint(-0.5, 0.866), SPoint(-0.5, 0.866), SPoint(-0.5, 0.866),
	SPoint(-0.5, 0.866), SPoint(-0.5, 0.866)
*/
