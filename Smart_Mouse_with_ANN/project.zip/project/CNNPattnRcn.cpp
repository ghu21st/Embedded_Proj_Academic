//Implementation file for CNNPattnRcn class
#include "CNNPattnRcn.h"

#include "resource.h" //for dialog window or other windows display resource
//
string CNNPattnRcn::m_strInputData=""; //Note: all static member variables need to be declared globally
//
//construction & destruction
CNNPattnRcn::CNNPattnRcn(HWND hwnd)
{
	m_iNumDefPoints=DATA_VECTOR_NUM+1;
	m_iNumPatterns=DATA_PATTERN_NUM;
	m_bActed=false; m_dHighestOutput=0;
	m_iBestFit=-1; m_iMatchedPattern=-1;
	m_hWnd=hwnd; m_PRMode=UNREADY;
	m_iNewInputNum=0;
	
	//init diagnose test file name
	strcpy(chFN_Square, "Square_Trans.dat");
	strcpy(chFN_Triangle, "Triangle_Trans.dat");

	//init CData and neural net class pointer
	m_pData=new CData(m_iNumPatterns, DATA_VECTOR_NUM);
	m_pNN=new CNeuralNet(DATA_VECTOR_NUM*2, m_iNumPatterns, NN_HIDDENLAYER_NUM, NN_NEURONPERHIDDEN_NUM,	NN_LEARNING_RATE);

}

CNNPattnRcn::~CNNPattnRcn()
{
	delete m_pData;
	delete m_pNN;
}

void CNNPattnRcn::Clear()	//clear data vectors
{
	m_vPathPoints.clear(); //clear points data from raw data
	m_vScaleDownPoints.clear(); //clear scaledown points data
	m_vectData.clear();		//clear vector data for NN

}

void CNNPattnRcn::GenerateInputData(vector<POINTS> v_In)	//after scale down, normalize input to suit for NN input need
{
	double d_TmpX, d_TmpY; 
	m_vectData.clear();

	if(v_In.size()<1){
		v_In=m_vScaleDownPoints;
	}
	//
	for(int i=1; i<v_In.size(); i++){
		d_TmpX=v_In[i].x-v_In[i-1].x;
		d_TmpY=v_In[i].y-v_In[i-1].y;

		SVector2D sv(d_TmpX, d_TmpY);
		Vector2DNorm(sv);

		m_vectData.push_back(sv.x);
		m_vectData.push_back(sv.y);
	}
}

bool CNNPattnRcn::PointsScaleDown(vector<POINTS> v_In)	//scale down points by inserting/deleting points have shortest distance
{
	//error check

	if(v_In.size()<m_iNumDefPoints){
		return false;
	}
	//
	m_vScaleDownPoints=v_In;
	//
	while(m_vScaleDownPoints.size()>m_iNumDefPoints){
		int iPointCnt=0;
		double dShortest=99999;
		
		//find shortest distance among all points.
		for(int iPN=2; iPN<m_vScaleDownPoints.size()-1; iPN++){ //keep the first and last points
			double d_Dist=sqrt((m_vScaleDownPoints[iPN].x-m_vScaleDownPoints[iPN-1].x)*
								(m_vScaleDownPoints[iPN].x-m_vScaleDownPoints[iPN-1].x)+
								(m_vScaleDownPoints[iPN].y-m_vScaleDownPoints[iPN-1].y)*
								(m_vScaleDownPoints[iPN].y-m_vScaleDownPoints[iPN-1].y));
			if(d_Dist<dShortest){
				dShortest=d_Dist;
				iPointCnt=iPN;
			}
		}

		//insert the new point and delete two old boundary points
		POINTS newPoint;
		newPoint.x=(m_vScaleDownPoints[iPointCnt-1].x+m_vScaleDownPoints[iPointCnt].x)/2;
		newPoint.y=(m_vScaleDownPoints[iPointCnt-1].y+m_vScaleDownPoints[iPointCnt].y)/2;
		m_vScaleDownPoints[iPointCnt-1]=newPoint;
		m_vScaleDownPoints.erase(m_vScaleDownPoints.begin()+iPointCnt);
	}
	return true;

}

bool CNNPattnRcn::MatchTest()	//test for a match from output vector
{
	//error check
	if(m_vectData.size()==0){
		MessageBox(NULL, "Error with the input vector!", "Error", MB_OK);
		return false;
	}

	//get the output vector
	vector<double> v_OutputTmp=m_pNN->Update(m_vectData);
	if(v_OutputTmp.size()==0){
		MessageBox(NULL, "Neural Network output error!", "Error", MB_OK);
		return false;
	}
	
	//find the matched pattern
	m_dHighestOutput=0;
	m_iBestFit=0;
	m_iMatchedPattern=999;
	
	for(int op=0; op<v_OutputTmp.size(); op++){
		if(v_OutputTmp[op]>= m_dHighestOutput){
			m_dHighestOutput=v_OutputTmp[op];
			m_iBestFit=op;
			if(v_OutputTmp[op] >= DATA_MATCH_THRESHOLD){
				m_iMatchedPattern=op;
			}
		}
	}
	//
	return true;

}

bool CNNPattnRcn::matchExec(int iIn)
{
	//check valid match number
	if(iIn>99){
		return false;
	}

	//
	if(iIn==0){	//Left
		ShellExecute(m_hWnd, "open", "notepad.exe", NULL, NULL, SW_SHOWNORMAL);

	}else if(iIn==1){	//right
		ShellExecute(m_hWnd, "open", "explorer.exe", NULL, NULL, SW_SHOWNORMAL);

	}else if(iIn==2){	//down
		ShellExecute(m_hWnd, "open", "calc.exe", NULL, NULL, SW_SHOWNORMAL);

	}else if(iIn==3){	//up
		ShellExecute(m_hWnd, "open", "winword.exe", NULL, NULL, SW_SHOWNORMAL);

	}else if((iIn>=4) && (iIn<=7)){	//counter-clockwise square
		ShellExecute(m_hWnd, "open", "mspaint.exe", NULL, NULL, SW_SHOWNORMAL);

	}else if((iIn>=8) && (iIn<=11)){	//clockwise square
		ShellExecute(m_hWnd, "open", "mspaint.exe", NULL, NULL, SW_SHOWNORMAL);

	}else if((iIn>=12) && (iIn<=14)){	//counter-clockwise triangle
		ShellExecute(m_hWnd, "open", "wmplayer.exe", NULL, NULL, SW_SHOWNORMAL);

	}else if((iIn>=15) && (iIn<=17)){	//clockwise triangle
		ShellExecute(m_hWnd, "open", "wmplayer.exe", NULL, NULL, SW_SHOWNORMAL);

	}else{
		return false;
	}

	return true;
}

//func. for NN oper.
bool CNNPattnRcn::TrainNN()		//Train NN
{
	m_PRMode=TRAINING;
	if(!m_pNN->TrainNN(m_pData, m_hWnd)){
		return false;
	}else{
		m_PRMode=READY;
		return true;
	}
}

void CNNPattnRcn::LearningMode()	//Learning mode
{
	m_PRMode=LEARNING;
	Clear();
	//
	InvalidateRect(m_hWnd, NULL, TRUE);
	UpdateWindow(m_hWnd);
}

bool CNNPattnRcn::DiagnoseNN(bool iFlag)
{	
	static PR_RunMode old_PRmode;
	//
	if(iFlag==true){
		old_PRmode=m_PRMode;
		m_PRMode=DIAGNOSING;
		Clear();
		//
		return true;
	}else{
		m_PRMode=old_PRmode;
		//
		return false;
	}
	//
	//read data from SM_TestData_Gen's .dat file
//	ofstream ofs_Square(chFN_Square);


}

bool CNNPattnRcn::WIN_Action(bool bIn, HINSTANCE hInst)	//drawing process, hInst for dialogbox
{
	//mouse pressed, bIn = true, adding points; otherwise, sample &analyze data
	if(bIn){
		Clear();
		m_bActed=true;
		return true;
	}

	//mouse released, analyze data
	if(PointsScaleDown(m_vPathPoints)){
		//create data input
		GenerateInputData(m_vScaleDownPoints);
		
		//check mode and acting
		if(m_PRMode==READY){
			if(!MatchTest()){
				return false;
			}
			
			//start exec *******************
			matchExec(m_iMatchedPattern);

		}else if(m_PRMode==LEARNING){
			if(MessageBox(NULL, "Do you want to accept what you input?", "Confirmation", MB_YESNO)==IDYES){
				//show the data input dialog window
				DialogBox(hInst, MAKEINTRESOURCE(IDD_Input_DLG), m_hWnd, DataInputDlgProc);
				
				//add new data into training set
				++m_iNewInputNum;
				ostringstream ostrTmp;
				ostrTmp<<m_iNewInputNum;
				string s1="User P"+ostrTmp.str();
				string s=s1+"- "+ m_strInputData;

				m_pData->AddNewData(m_vectData, s);

				//re-construct the NN
				delete m_pNN;
				++m_iNumPatterns;
				m_pNN=new CNeuralNet(DATA_VECTOR_NUM*2, m_iNumPatterns, NN_HIDDENLAYER_NUM, NN_NEURONPERHIDDEN_NUM, NN_LEARNING_RATE);
				
				//Train the new data set with the new customer inputed vector
				if(!TrainNN()){
					return false;
				}
				m_PRMode=READY;
			}else{
				m_vectData.clear();
			}
		}else{
			MessageBox(NULL, "Please train the ANN first. Wrong running mode!", "Error", MB_OK);
			return false;
		}
	}
	m_bActed=bIn;

	return true;
}

void CNNPattnRcn::Render(HDC &hdc, int cxClient, int cyClient) //Render the window display
{
	//
	if(m_PRMode==TRAINING){
		ostringstream ostrTmp1; 
		ostrTmp1<<m_pNN->getNumEpoch();
		string s1="Epoch: "+ostrTmp1.str();
		TextOut(hdc, 5, 5, s1.c_str(), s1.size());
		
		ostringstream ostrTmp2;
		ostrTmp2<<m_pNN->getNNError();
		string s2="Error: "+ostrTmp2.str();
		TextOut(hdc, cxClient/2, 5, s2.c_str(), s2.size());
		
		string s3="Training...";
		TextOut(hdc, 5, cyClient-25, s3.c_str(), s3.size());
	}else if(m_PRMode==READY){
		string s4="Ready! Hold left mouse button and draw...";
		string s5="'T'-Training, 'L'-Learning, 'D'-Diagnosing, 'ESC'-Quit";
		TextOut(hdc, 5, cyClient-40, s4.c_str(), s4.size());
		TextOut(hdc, 5, cyClient-20, s5.c_str(), s5.size());
	}else if(m_PRMode==LEARNING){
		string s4="Input new gesture...";
		TextOut(hdc, 5, cyClient-25, s4.c_str(), s4.size());
	}else{
		string s4="'T'-Training, 'L'-Learning, 'D'-Diagnosing, 'ESC'-Quit";
		TextOut(hdc, 5, cyClient-25, s4.c_str(), s4.size());
	}

	//recognition result showing and mouse drawing 
	if(!m_bActed){
		if(m_dHighestOutput>0){
			if((m_vScaleDownPoints.size()>1)&&(m_PRMode!=LEARNING)){
				if(m_dHighestOutput<DATA_MATCH_THRESHOLD){ //guessing the pattern
					ostringstream ostrTmp1;
					double d_Out=m_dHighestOutput*100;
					ostrTmp1<<d_Out;
					string s="Guessing ("+ostrTmp1.str()+"%): ";
					s+=m_pData->getPatternName(m_iBestFit);
					TextOut(hdc, 5, 5, s.c_str(), s.size());
				}else{	//give the exact pattern
					ostringstream ostrTmp2;
					double d_Out2=m_dHighestOutput*100;
					ostrTmp2<<d_Out2;
					string s2="Matched ("+ostrTmp2.str()+"%): ";
					s2+=m_pData->getPatternName(m_iMatchedPattern);
					TextOut(hdc, 5, 5, s2.c_str(), s2.size());
				}
			}else if(m_PRMode!=LEARNING){
				SetTextColor(hdc, RGB(255, 0, 0));
				string s="Please try again. Not enough points were drawn. ";
				TextOut(hdc, 5, cyClient-90, s.c_str(), s.size());
				SetTextColor(hdc, RGB(0, 0, 0));
			}
		}
	}

	//draw the trace of the user drawing and the scale down points
//	if(m_iMatchedPattern>99){	//check if valid matched pattern found, 
//		return;
//	}

	if(m_vPathPoints.size()>1){
		MoveToEx(hdc, m_vPathPoints[0].x, m_vPathPoints[0].y, NULL);
		for(int i=0; i<m_vPathPoints.size(); i++){
			LineTo(hdc, m_vPathPoints[i].x, m_vPathPoints[i].y);
		}
	}

	if(!m_bActed && (m_vScaleDownPoints.size()>1)){
		MoveToEx(hdc, m_vScaleDownPoints[0].x, m_vScaleDownPoints[0].y, NULL);
		for(int j=0; j<m_vScaleDownPoints.size(); j++){
			POINTS pt=m_vScaleDownPoints[j];
			Ellipse(hdc, pt.x-2, pt.y-2, pt.x+1, pt.y+1);
		}
	}

}

//user input dialog for windows
BOOL CALLBACK CNNPattnRcn::DataInputDlgProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	HWND hwndEditBox=GetDlgItem(hwnd, IDC_Input_EDIT);

	switch(msg){
	case WM_INITDIALOG:
		//initialize dialog...

		//
		return TRUE;
		break;

	case WM_COMMAND:
		switch(LOWORD(wparam)){
		case IDOK:
			//get input data from edit box in the dialog
			SetFocus(hwndEditBox);
			char chTmp[70];
			GetWindowText(hwndEditBox, chTmp, 70);
			//
//			if(chTmp==""){
//				strcpy(chTmp, "Empty Input");
//			}
			
			m_strInputData=chTmp;

			//end the dialog
			EndDialog(hwnd, 0);
			
			return TRUE;
			break;

		case IDCANCEL:
			EndDialog(hwnd, 0);

			return TRUE;
			break;
		}
		break;
	}
	//
	return FALSE;
}


double CNNPattnRcn::Diag_Test(vector<POINTS> v_In)	//for diagnose using
{
	Clear();

//	bRet=pNNRcn->PointsScaleDown(v_PathPoints);
	GenerateInputData(v_In);
	MatchTest();
	double dRet=getHighestOutput() * 100;

	return dRet;
}
