only change error threshold, others are fixed






//System main global parameter defination 
#ifndef DEFINE_H
#define DEFINE_H

//Data parameter
#define DATA_PATTERN_NUM 18	 //Up, down, left, right, clockwise, counter-clockwise square and triangle
#define DATA_VECTOR_NUM 16	 //16 input vectors (32 value, X & Y) must be even number. 
#define DATA_MATCH_THRESHOLD 0.9999 //0.8-0.99, for making sure about the recognition
 
//Neural network parameter
	//basic NN settings
#define NN_INPUT_NUM 32			// must = DATA_VECTOR_NUM * 2
#define NN_HIDDENLAYER_NUM 1	// must be 1

#define NN_NEURONPERHIDDEN_NUM 16//8, 12, 14, 16, 18, 20, 24 good = NN_INPUT_NUM / 2 +++++++++++++++++++++++++++

#define NN_OUTPUT_NUM 18		// must = DATA_PATTERN_NUM

#define NN_SIGMOID_P 1			// good = 1
#define NN_BIAS	-1				// must = -1

#define NN_LEARNING_RATE 0.9    //good=0.6-0.8, need to be tested, 0.1 to 1.2
#define NN_ERROR_THRESHOLD 0.03 //good=0.003, need to be tested, 0.001 to 0.1

	//NN improvement tricks (momentum , jitter...)
#define NN_MOMENTUM_RATE 0.9	//good=0.9, for momentum (in NNBackprop )
#define NN_JITTER_RATE 0.05		//good =0.01 to 0.2, for jitter (in Update)			

#endif
