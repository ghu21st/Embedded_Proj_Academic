//Implementation file for CData.h
//
//Improvement:
//1) no action sequence demand for basic shape recognition
//2) right mouse guesture recognition change to left mouse guesture
//3) better generalization
//4) leave customer guesture drawing trace on screen with sample vector point showing
//5) test data automatic generalization for analyze to achieve better ANN performance
//6) automatic test and measurement to evaluate the ANN performance 
//7) record the rotation and position change result into file for future analysis
//8) quality control data and chart base on the test data
//9) record the ANN basic shape trained weights into a file, so for next start, no training demand required
//10) self-learning ability which can learn the ANN user data/new guesture (ask before recording)


#include "CData.h"
//--------------------------------------------------------------------------------
//orignal data (Note: windows coordinate is a kind of Y axis mirror of normal coordinate along X axis)
	//to minimize the action sequence requirement (side effect of ANN), set all possible sequence as standard training input
const double InputVectorDef[DATA_PATTERN_NUM][DATA_VECTOR_NUM*2]={//6 to 9 pattern,16 input vect,32 points
	-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0, //left
	 1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,	//right
	0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,	//Down (windows)
	0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,-1, //Up (windows)

	//counter-clockwise square
	1,0,1,0,1,0,1,0,0,-1,0,-1,0,-1,0,-1,-1,0,-1,0,-1,0,-1,0,0,1,0,1,0,1,0,1, //_, |, -, |
	0,-1,0,-1,0,-1,0,-1,-1,0,-1,0,-1,0,-1,0,0,1,0,1,0,1,0,1,1,0,1,0,1,0,1,0, //|, -, |, _
	-1,0,-1,0,-1,0,-1,0,0,1,0,1,0,1,0,1,1,0,1,0,1,0,1,0,0,-1,0,-1,0,-1,0,-1, //-, |, _, |
	0,1,0,1,0,1,0,1,1,0,1,0,1,0,1,0,0,-1,0,-1,0,-1,0,-1,-1,0,-1,0,-1,0,-1,0, //|, _, |, -

	//clockwise square
	1,0,1,0,1,0,1,0,0,1,0,1,0,1,0,1,-1,0,-1,0,-1,0,-1,0,0,-1,0,-1,0,-1,0,-1,
	0,1,0,1,0,1,0,1,-1,0,-1,0,-1,0,-1,0,0,-1,0,-1,0,-1,0,-1,1,0,1,0,1,0,1,0,
	-1,0,-1,0,-1,0,-1,0,0,-1,0,-1,0,-1,0,-1,1,0,1,0,1,0,1,0,0,1,0,1,0,1,0,1,
	0,-1,0,-1,0,-1,0,-1,1,0,1,0,1,0,1,0,0,1,0,1,0,1,0,1,-1,0,-1,0,-1,0,-1,0,

	//counter-clockwise triangle
	1,0,1,0,1,0,1,0,1,0,1,0,-0.5,-0.866,-0.5,-0.866,-0.5,-0.866,-0.5,-0.866,-0.5,-0.866,-0.5,0.866,-0.5,0.866,-0.5,0.866,-0.5,0.866,-0.5,0.866, // _, \, /
	-0.5,-0.866,-0.5,-0.866,-0.5,-0.866,-0.5,-0.866,-0.5,-0.866,-0.5,0.866,-0.5,0.866,-0.5,0.866,-0.5,0.866,-0.5,0.866,1,0,1,0,1,0,1,0,1,0,1,0, // \, /, _
	-0.5,0.866,-0.5,0.866,-0.5,0.866,-0.5,0.866,-0.5,0.866,1,0,1,0,1,0,1,0,1,0,1,0,-0.5,-0.866,-0.5,-0.866,-0.5,-0.866,-0.5,-0.866,-0.5,-0.866,	// /, _, \

	//clockwise triangle
	0.5,-0.866,0.5,-0.866,0.5,-0.866,0.5,-0.866,0.5,-0.866,0.5,0.866,0.5,0.866,0.5,0.866,0.5,0.866,0.5,0.866, -1,0,-1,0,-1,0,-1,0,-1,0,-1,0, 
	0.5,0.866,0.5,0.866,0.5,0.866,0.5,0.866,0.5,0.866, -1,0,-1,0,-1,0,-1,0,-1,0,-1,0,0.5,-0.866,0.5,-0.866,0.5,-0.866,0.5,-0.866,0.5,-0.866,
	-1,0,-1,0,-1,0,-1,0,-1,0,-1,0,0.5,-0.866,0.5,-0.866,0.5,-0.866,0.5,-0.866,0.5,-0.866, 0.5,0.866,0.5,0.866,0.5,0.866,0.5,0.866,0.5,0.866	

};

const string PatternNameDef[DATA_PATTERN_NUM]={
	"Left", "Right", "Down", "Up", 
	"Counter-clockwise square", "Counter-clockwise square", "Counter-clockwise square", "Counter-clockwise square", 
	"Clockwise square", "Clockwise square", "Clockwise square", "Clockwise square", 
	"Counter-clockwise triangle", "Counter-clockwise triangle", "Counter-clockwise triangle", 
	"Clockwise triangle", "Clockwise triangle", "Clockwise triangle"
};

//-----------------------------------------------------------------------------

//
CData::CData(int i_PatternNum, int i_PatternVectNum)
{
	m_iNumPattern=i_PatternNum;
	m_iSizePatternVector=i_PatternVectNum;
	//
	InitData();
	CreateTrainingDataSet();
}

void CData::InitData()
{
	for(int i=0; i<m_iNumPattern; i++){
		vector<double> vectTmp;
		for(int j=0; j<m_iSizePatternVector*2; j++){
			vectTmp.push_back(InputVectorDef[i][j]);
		}
		m_vectPatternRec.push_back(vectTmp);
		m_vectPatternName.push_back(PatternNameDef[i]);
	}
}

void CData::CreateTrainingDataSet()	
{
	m_vectDataSetIn.clear();
	m_vectDataSetOut.clear();
	//
	for(int i=0; i<m_iNumPattern; i++){
		m_vectDataSetIn.push_back(m_vectPatternRec[i]);
		//
		vector<double> vectTmp;
		for(int j=0; j<m_iNumPattern; j++){
			if(j==i){
				vectTmp.push_back(1);
			}else{
				vectTmp.push_back(0);
			}
		}
		m_vectDataSetOut.push_back(vectTmp);
	}

}

bool CData::AddNewData(vector<double> &v_In, string &str_In)
{
	//error check
	if(v_In.size()!=m_iSizePatternVector*2){
		MessageBox(NULL, "New pattern data has incorrect vector size (points number)!", 
							"Error", MB_OK);
		return false;
	}
	
	//Add new data to pattern record.
	m_vectPatternRec.push_back(v_In);
	m_vectPatternName.push_back(str_In);

	++m_iNumPattern;

	CreateTrainingDataSet();
	return true;

}

string CData::getPatternName(int i_Pos)
{

	if((i_Pos<m_vectPatternName.size())&&(m_vectPatternName.size()>0)){
		return m_vectPatternName[i_Pos];
	}else{
		return "";
	}
}

