//Implementation for CMatrix2D.h
#include "CMatrix2D.h"
//
void CMat2DTrans::Identity_Mat()
{
	//define standard identity matrix (3)
	m_Mat2D.m11=1; m_Mat2D.m11=0; m_Mat2D.m11=0;
	m_Mat2D.m11=0; m_Mat2D.m11=1; m_Mat2D.m11=0;
	m_Mat2D.m11=0; m_Mat2D.m11=0; m_Mat2D.m11=1;
}
	
void CMat2DTrans::Vertex_Transform2D(vector<SPoint> &v_In, double rot, double sx, double sy,
									 	double dx, double dy)
{
	SPoint v_Out(0, 0); //temporarily to keep the output value
//	POINTS v_Out; 
//	v_Out.x=0; v_Out.y=0;
	//
	for(int i=0; i<v_In.size(); i++){
		v_Out.x = v_In[i].x * sx * cos(rot) - v_In[i].y * sy * sin(rot) + dx;
		v_Out.y = v_In[i].x * sx * sin(rot) + v_In[i].y * sy * cos(rot) + dy;

		v_In[i].x=v_Out.x;
		v_In[i].y=v_Out.y;
	}
}

									 
