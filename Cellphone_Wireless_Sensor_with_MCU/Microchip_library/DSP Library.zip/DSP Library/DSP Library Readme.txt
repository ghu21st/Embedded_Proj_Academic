Release Notes for MPLAB(R) C30 DSP Library v2.01
February 23, 2006

--------------------------------------------------
Table of Contents
--------------------------------------------------
1. What's New
2. Introduction
3. Using the DSP Library
4. DSP Code Size and Cycles


--------------------------------------------------
1. What's New
--------------------------------------------------
This dot release of the DSP Library fixes several DSP Library functions that
are affected by the Y Data Dependency errata.  The following functions have
been modified for this release:
     FFTComplexIP() (which is used by all FFT and IFFT functions)
     FIR()
     FIRLMS()
     FIRLMSNormalized()

Updates to the program size and cycle counts for each function are provided
in the header of the respective assembly source file.


--------------------------------------------------
2. Introduction
--------------------------------------------------
This package includes the DSP Algorithm Library for the dsPIC30F
family of devices. All devices in the family are supported.


--------------------------------------------------
3. Using the DSP Library
--------------------------------------------------
The dsPIC30 DSP library should be unzipped in the "yourfolder\MPLAB C30\lib" directory,
where "yourfolder" refers to the directory to which you extracted the DSP Library
files from "DSP Library".  There is one library archive (.A) file
for the libray:  LIBDSP.A.

If using MPLAB IDE, please ensure that the Library Path is correctly set in
"Project >> Build Options >> Project" ("General" tab), to "yourfolder\MPLAB C30\lib".

If using the ASM30/LINK30 command-line, please ensure that the library path is correctly
set and the library name is correctly specified in the linker command. Refer to the
MPLAB ASM30, MPLAB LINK30 and Utilities User's Guide (DS51317B) for details about
MPLAB ASM30 and LINK30 command-line syntax.

The DSP.H header file is supplied with the library and should be included in all
source files that reference the DSP Library.  This file should be located in the
"yourfolder\MPLAB C30\support\h" directory, where "yourfolder" refers to the directory
to which you extracted the DSP Library files from "DSP Library.zip".


--------------------------------------------------
4. DSP Code Size and Cycles
--------------------------------------------------
Some functions of the DSP Library are written in "C".  Since the profile of these
functions will vary with the compiler, they are not included in the dsPIC
Language Tools Libraries Manual. Please use the following table instead:

                   Program
Function           Words(1)   Cycles(2)
----------------   --------   --------------
BartlettInit       56         330,984    (3)
BlackmanInit       65         1,378,928  (3)
HammingInit        39         816,997    (3)
HanningInit        39         821,651    (3)
KaiserInit         229        1,814,927  (3)
MatrixInvert       308        2,521,742  (4)
CosFactorInit      89         (5)
TwidFactorInit     102        (6)

(1) 24-bit instructions
(2) Including C-function call and return overheads
(3) For a 128 element window
(4) For a 16x16 element matrix

(5)
=============================
transform  #complex
size       elements  #cycles
=============================
32-point      16     92,993
64-point      32     177,065
128-point     64     353,324
256-point     128    692,970
=============================

(6)
==========================================
              transform  #complex
              size       elements  #cycles
==========================================
direct set    32-point      16     108,278
conjugate set 32-point      16     95,968
==========================================
direct set    64-point      32     211,694
conjugate set 64-point      32     187,330  
==========================================
direct set    128-point     64     417,663  
conjugate set 128-point     64     372,605  
==========================================
direct set    256-point     128    839,896  
conjugate set 256-point     128    735,385  
==========================================


