Momentum Data Systems dsPICworks

Install Version 1.00.04 for dsPIC works version 1.0, release 1.0.1.

19-Nov-2003
---------------------------------------------------

Please see the manual in \doc\dsPICworks Users Guide.pdf for installation and usage information.  

To uninstall dsPICworks you may use Start->Settings->Control Panel->Add/Remove software,  or simply run setup.exe again.

The install will create a shortcut to dsPICworks on your desktop. If you do not wish to have it you can simply delete the short cut and run dsPICworks from the menu Start-> Programs-> MDS -> dsPICworks.

Software installation requires that you have Windows administrative privileges.

We suggest rebooting your PC after installing the software.


Errata/Known problems/Change log
---------------------------------------------------

Version 1.00.0x Opening .tim or .fre file launches dsPICworks, but the file fails to open.